const http = require('http')
const express = require('express')
const port = process.env.PORT || 4000
const app = express()
const sev = http.createServer(app)
sev.listen(port, function () {
  console.log('listening on *:' + port)
})
const io = require('socket.io')(sev)
io.on('connection', function (socket) {
  socket.on('web_wallet_emit', function (msg) {
    console.log(msg)
    io.emit('web_wallet_emit', msg)
  })
  socket.on('web_wallet_on', function (msg) {
    console.log(msg)
    io.emit('web_wallet_on', msg)
  })
  socket.on('takePicture', function (msg) {
    console.log('takePicture',msg)
    io.emit('takePicture', msg)
  })
  socket.on('init', function (msg) {
    console.log(msg)
    io.emit('init', msg)
  })

  socket.on('createRoom', function(name){
    console.log('create', name);
    socket.join(name);
    socket.room = name;
  });

  socket.on('closeRoom', function(name){
    console.log('closeRoom', name);``
    delete socket.room
    socket.leave(name);
  });

  socket.on('closeRoom', function(name){
    console.log('closeRoom', name);
    delete socket.room
    socket.leave(name);
  });

  socket.on('join', function(name, callback){
    const socketIds = socketIdsInRoom(name);
    callback(socketIds);
  });

  socket.on('leave', function(idLeaved){
    console.log('leave', idLeaved);
    io.emit('leave',idLeaved)
  });

  socket.on('web_wallet_emit', function(msg){
    console.log('web_wallet_emit', msg);
    io.emit('web_wallet_emit',msg)
  });

  socket.on('exchange', function(data){
    data.from = socket.id;
    console.log('fromIP: %s -- toIp: %s',data.from,data.toIp)
    const to = io.sockets.connected[data.toIp];
    to.emit('exchange', data);
  });
  socket.on('disconnect', function(){
    if (socket.room) {
      const room = socket.room;
      io.to(room).emit('leave', socket.id);
      socket.leave(room);
    }
  });
})

function socketIdsInRoom(name) {
  let socketIds = io.nsps['/'].adapter.rooms[name].sockets;
  if (socketIds) {
    const collection = [];
    for (const key in socketIds) {
      collection.push(key);
    }
    return collection;
  } else {
    return [];
  }
}
