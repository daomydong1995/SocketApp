const http = require('http')
const express = require('express')
const port = process.env.PORT || 4000
const app = express()
const sev = http.createServer(app)
sev.listen(port, function () {
  console.log('listening on *:' + port)
})
const io = require('socket.io')(sev)
io.on('connection', function (socket) {
  socket.on('web_wallet_emit', function (msg) {
    console.log(msg)
    io.emit('web_wallet_emit', msg)
  })
  socket.on('web_wallet_on', function (msg) {
    console.log(msg)
    io.emit('web_wallet_on', msg)
  })
  socket.on('init', function (msg) {
    console.log(msg)
    io.emit('init', msg)
  })
})
