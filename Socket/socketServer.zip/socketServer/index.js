const http = require('http')
const express = require('express')
const port = process.env.PORT || 4000
const app = express()
const sev = http.createServer(app)
var os = require('os');
var ifaces = os.networkInterfaces();

Object.keys(ifaces).forEach(function (ifname) {
  var alias = 0;
  ifaces[ifname].forEach(function (iface) {
    if ('IPv4' !== iface.family || iface.internal !== false) {
      return;
    }
    if (alias >= 1) {
      console.log(ifname + ':' + alias, iface.address);
    } else {
      console.log(ifname, iface.address);
    }
    ++alias;
  });
});
sev.listen(port, function () {
  console.log('listening on *:' + port)
})
const io = require('socket.io')(sev)
io.on('connection', function (socket) {
  socket.on('web_wallet_emit', function (msg) {
    try{
      // console.log('web_wallet_emit', msg)
      io.emit('web_wallet_emit', msg)
    }catch (e) {
      console.log('web_wallet_emit - error:', e)
    }
  })
  socket.on('web_wallet_emit_action', function (msg) {
    try{
      // console.log('web_wallet_emit', msg)
      io.emit('web_wallet_emit_action', msg)
    }catch (e) {
      console.log('web_wallet_emit_action - error:', e)
    }
  })
  socket.on('web_wallet_on', function (msg) {
    try {
      // console.log('web_wallet_on' ,msg)
      io.emit('web_wallet_on', msg)
    }catch (e) {
      console.log('web_wallet_on - error:', e)
    }
  })
  socket.on('take_picture', function (msg) {
    try {
      // console.log('take_picture',msg)
      io.emit('take_picture', msg)
    }catch (e) {
      console.log('take_picture - error:', e)
    }

  })
  socket.on('open_sign_writing', function(msg){
    try {
      // console.log('open_sign_writing', msg);
      io.emit('open_sign_writing',msg)
    } catch (e) {

    }
  });

  socket.on('init', function (msg) {
    try {
      console.log('init',msg)
      io.emit('init', msg)
    } catch (e) {
      console.log('init - error:',e)
    }
  })

  socket.on('create_room', function(name, callback){
    try {
      if(!socket.room) {
        console.log('create_room', name);
        socket.join(name);
        socket.room = name;
      }
      callback();
    } catch (e) {
      console.log('create_room - error:', e);
    }
  });


  socket.on('close_room', function(name){
    try {
      console.log('close_room', name);
      // socket.leave(name);
    } catch (e) {
      console.log('close_room - error:', e);
    }
  });

  socket.on('join', function(name, callback){
    try {
      console.log('join', name);
      const socketIds = socketIdsInRoom(name);
      callback(socketIds);
    } catch (e) {
      console.log('join - error', e);
    }
  });

  socket.on('leave', function(idLeaved){
    try {
      console.log('levea', idLeaved)
      io.emit('leave',idLeaved)
    } catch (e) {
      console.log('leave - error:', e);
    }

  });

  socket.on('exchange', function(data){
    try {
      data.from = socket.id;
      const to = io.sockets.connected[data.toIp];
      to.emit('exchange', data);
    } catch (e) {
      console.log('exchange - error:',e)
    }
  });
  socket.on('disconnect', function(){
    if (socket.room) {
      const room = socket.room;
      io.to(room).emit('leave', socket.id);
      socket.leave(room);
    }
  });
})

function socketIdsInRoom(name) {
  let socketIds = io.nsps['/'].adapter.rooms[name].sockets;
  if (socketIds) {
    const collection = [];
    for (const key in socketIds) {
      collection.push(key);
    }
    console.log(collection)
    return collection;
  } else {
    return [];
  }
}
